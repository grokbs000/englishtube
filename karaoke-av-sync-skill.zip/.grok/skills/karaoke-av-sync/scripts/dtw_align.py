#!/usr/bin/env python3
"""
Advanced alignment using Dynamic Time Warping (DTW).

Aligns lyric lines (or characters) against Whisper word stream with a
globally optimal monotonic path. Prefer this when sliding-window fuzzy
matching yields high MAE or many unmatched lines.

Usage (usually called from batch_calibrate_whisper.py --dtw):
  from dtw_align import dtw_align_lyrics
  cues = dtw_align_lyrics(lyrics, whisper_words)
"""

from __future__ import annotations

import re
from typing import Any

import numpy as np


def normalize(text: str) -> str:
    return re.sub(r"[^\w\s]", "", text.lower()).strip()


def char_sequence(text: str) -> list[str]:
    """Flatten text into character sequence (ignoring spaces)."""
    return list(normalize(text).replace(" ", ""))


def local_distance(a: str, b: str) -> float:
    """Simple character distance: 0 if equal, 1 otherwise."""
    return 0.0 if a == b else 1.0


def dtw(seq_a: list[str], seq_b: list[str]) -> tuple[float, list[tuple[int, int]]]:
    """
    Classic DTW. Returns (total_cost, path) where path is list of (i, j).
    Uses pure NumPy for clarity; for production consider fastdtw or dtaidistance.
    """
    n, m = len(seq_a), len(seq_b)
    if n == 0 or m == 0:
        return float("inf"), []

    cost = np.full((n + 1, m + 1), np.inf)
    cost[0, 0] = 0.0

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            d = local_distance(seq_a[i - 1], seq_b[j - 1])
            cost[i, j] = d + min(cost[i - 1, j], cost[i, j - 1], cost[i - 1, j - 1])

    # Backtrack
    path = []
    i, j = n, m
    while i > 0 and j > 0:
        path.append((i - 1, j - 1))
        candidates = [
            (cost[i - 1, j - 1], i - 1, j - 1),
            (cost[i - 1, j], i - 1, j),
            (cost[i, j - 1], i, j - 1),
        ]
        _, i, j = min(candidates, key=lambda x: x[0])
    path.reverse()
    return float(cost[n, m]), path


def dtw_align_lyrics(
    lyrics: list[dict],
    words: list[dict],
) -> list[dict]:
    """
    Align each lyric line independently with a local DTW against a sliding
    region of the word stream, then stitch results monotonically.
    """
    result = []
    cursor = 0
    n_words = len(words)
    all_chars = []
    word_char_map = []  # maps character index → word index
    for wi, w in enumerate(words):
        chars = char_sequence(w["word"])
        for _ in chars:
            word_char_map.append(wi)
        all_chars.extend(chars)

    for line in lyrics:
        text = line.get("en") or line.get("text", "")
        line_chars = char_sequence(text)
        if not line_chars:
            result.append({**line, "start": None, "end": None, "source": "unmatched"})
            continue

        # Search a limited forward window of characters
        search_start = min(cursor, len(all_chars))
        search_end = min(search_start + len(line_chars) * 4 + 20, len(all_chars))
        window_chars = all_chars[search_start:search_end]

        if not window_chars:
            result.append({**line, "start": None, "end": None, "source": "unmatched"})
            continue

        cost, path = dtw(line_chars, window_chars)
        if not path:
            result.append({**line, "start": None, "end": None, "source": "unmatched"})
            continue

        # Map path back to word indices
        word_indices = set()
        for _, j in path:
            global_char_idx = search_start + j
            if global_char_idx < len(word_char_map):
                word_indices.add(word_char_map[global_char_idx])

        if not word_indices:
            result.append({**line, "start": None, "end": None, "source": "unmatched"})
            continue

        wi_start = min(word_indices)
        wi_end = max(word_indices)
        start_t = words[wi_start]["start"]
        end_t = words[wi_end]["end"] + 0.15

        result.append({
            **line,
            "start": round(start_t, 3),
            "end": round(end_t, 3),
            "source": "whisper+dtw",
            "dtw_cost": round(cost, 2),
            "words": words[wi_start:wi_end + 1],
        })
        cursor = word_char_map[min(search_start + path[-1][1], len(word_char_map) - 1)] + 1

    return result


if __name__ == "__main__":
    print("dtw_align.py is a library module. Import dtw_align_lyrics().")
