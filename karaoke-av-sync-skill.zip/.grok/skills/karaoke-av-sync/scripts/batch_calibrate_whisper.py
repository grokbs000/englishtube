#!/usr/bin/env python3
"""
Tier 2: Word-level alignment using faster-whisper + sliding-window fuzzy match
(or optional DTW via dtw_align.py).

Usage:
  python batch_calibrate_whisper.py --audio song.wav --lyrics lyrics.json --out cues.json
  python batch_calibrate_whisper.py --audio song.wav --lyrics lyrics.json --out cues.json --dtw
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

# Optional heavy deps – import inside functions so the skeleton still loads
# without them installed.


def normalize(text: str) -> str:
    return re.sub(r"[^\w\s]", "", text.lower()).strip()


def token_set_ratio(a: str, b: str) -> float:
    """Lightweight token-set ratio (no rapidfuzz dependency required)."""
    ta = set(normalize(a).split())
    tb = set(normalize(b).split())
    if not ta or not tb:
        return 0.0
    inter = len(ta & tb)
    return 2.0 * inter / (len(ta) + len(tb))


def run_whisper(audio_path: Path, model_size: str = "base.en") -> list[dict]:
    from faster_whisper import WhisperModel

    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(
        str(audio_path),
        word_timestamps=True,
        beam_size=5,
        vad_filter=True,
        language="en",
    )
    words = []
    for seg in segments:
        if seg.words:
            for w in seg.words:
                words.append({
                    "word": w.word.strip(),
                    "start": w.start,
                    "end": w.end,
                })
    return words


def estimate_syllables(text: str) -> int:
    # Very rough English syllable estimate
    text = normalize(text)
    if not text:
        return 1
    return max(1, len(re.findall(r"[aeiouy]+", text)))


def sliding_window_align(
    lyrics: list[dict],
    words: list[dict],
    threshold: float = 0.42,
) -> list[dict]:
    """Anchor each lyric line to a window of Whisper words."""
    result = []
    cursor = 0
    n = len(words)

    for line in lyrics:
        text = line.get("en") or line.get("text", "")
        syll = estimate_syllables(text)
        window = max(3, syll + 2)
        best_score = 0.0
        best_start = cursor
        best_end = min(cursor + window, n)

        for i in range(cursor, min(cursor + 40, n)):  # limited look-ahead
            j = min(i + window, n)
            window_text = " ".join(w["word"] for w in words[i:j])
            score = token_set_ratio(text, window_text)
            # slight preference for similar duration
            if score > best_score:
                best_score = score
                best_start = i
                best_end = j

        if best_score >= threshold and best_end > best_start:
            start_t = words[best_start]["start"]
            end_t = words[best_end - 1]["end"] + 0.15
            result.append({
                **line,
                "start": round(start_t, 3),
                "end": round(end_t, 3),
                "source": "whisper",
                "match_score": round(best_score, 3),
                "words": words[best_start:best_end],
            })
            cursor = best_end
        else:
            result.append({
                **line,
                "start": None,
                "end": None,
                "source": "unmatched",
            })
    return result


def monotonic_smooth(cues: list[dict], gap: float = 0.05) -> list[dict]:
    """Ensure start times are strictly increasing."""
    prev_end = 0.0
    for c in cues:
        if c.get("start") is None:
            continue
        if c["start"] < prev_end:
            c["start"] = round(prev_end + gap, 3)
        if c.get("end") is not None and c["end"] < c["start"]:
            c["end"] = round(c["start"] + 0.3, 3)
        prev_end = c.get("end") or c["start"]
    return cues


def main() -> None:
    parser = argparse.ArgumentParser(description="Tier 2 Whisper calibration")
    parser.add_argument("--audio", required=True, help="WAV/MP3 path")
    parser.add_argument("--lyrics", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--model", default="base.en")
    parser.add_argument("--dtw", action="store_true", help="Use DTW instead of sliding window")
    parser.add_argument("--threshold", type=float, default=0.42)
    args = parser.parse_args()

    lyrics = json.loads(Path(args.lyrics).read_text(encoding="utf-8"))
    words = run_whisper(Path(args.audio), args.model)

    if args.dtw:
        from dtw_align import dtw_align_lyrics
        cues = dtw_align_lyrics(lyrics, words)
        for c in cues:
            c["source"] = "whisper+dtw"
    else:
        cues = sliding_window_align(lyrics, words, threshold=args.threshold)

    cues = monotonic_smooth(cues)
    Path(args.out).write_text(json.dumps(cues, ensure_ascii=False, indent=2), encoding="utf-8")
    matched = sum(1 for c in cues if c.get("start") is not None)
    print(f"Matched {matched}/{len(cues)} lines → {args.out}")


if __name__ == "__main__":
    main()
