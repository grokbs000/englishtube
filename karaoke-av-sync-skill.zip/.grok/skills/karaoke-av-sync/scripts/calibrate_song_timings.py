#!/usr/bin/env python3
"""
Tier 1: Calibrate bilingual lyrics against official YouTube VTT subtitles.
Usage:
  python calibrate_song_timings.py --video-id <YT_ID> --lyrics lyrics.json --out cues.json
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any


def fetch_vtt(video_id: str, work_dir: Path) -> Path | None:
    """Download English VTT (official or auto) via yt-dlp."""
    cmd = [
        "yt-dlp",
        "--write-subs",
        "--write-auto-subs",
        "--sub-langs", "en",
        "--skip-download",
        "--sub-format", "vtt",
        "-o", str(work_dir / "%(id)s"),
        f"https://www.youtube.com/watch?v={video_id}",
    ]
    subprocess.run(cmd, check=False, capture_output=True)
    candidates = list(work_dir.glob(f"{video_id}*.vtt"))
    return candidates[0] if candidates else None


def parse_vtt(vtt_path: Path) -> list[dict[str, Any]]:
    """Parse VTT into list of {start, end, text}."""
    content = vtt_path.read_text(encoding="utf-8", errors="ignore")
    cues = []
    # Simple VTT parser (handles most YouTube output)
    blocks = re.split(r"\n\n+", content)
    time_re = re.compile(
        r"(\d{2}:)?(\d{2}):(\d{2})\.(\d{3})\s-->\s(\d{2}:)?(\d{2}):(\d{2})\.(\d{3})"
    )
    for block in blocks:
        lines = block.strip().splitlines()
        if not lines:
            continue
        m = time_re.search(lines[0])
        if not m:
            continue
        def to_sec(h, m_, s, ms):
            h = int(h or 0)
            return h * 3600 + int(m_) * 60 + int(s) + int(ms) / 1000.0
        start = to_sec(m.group(1), m.group(2), m.group(3), m.group(4))
        end = to_sec(m.group(5), m.group(6), m.group(7), m.group(8))
        text = " ".join(lines[1:]).strip()
        text = re.sub(r"<[^>]+>", "", text)  # strip tags
        if text:
            cues.append({"start": start, "end": end, "text": text})
    return cues


def normalize(text: str) -> str:
    return re.sub(r"[^\w\s]", "", text.lower()).strip()


def align_lyrics_to_vtt(
    lyrics: list[dict], vtt_cues: list[dict], min_ratio: float = 0.65
) -> list[dict]:
    """Align each lyric line to best matching VTT cue via SequenceMatcher."""
    result = []
    used = set()
    for line in lyrics:
        best_ratio = 0.0
        best_idx = -1
        norm_line = normalize(line.get("en") or line.get("text", ""))
        for i, cue in enumerate(vtt_cues):
            if i in used:
                continue
            ratio = SequenceMatcher(None, norm_line, normalize(cue["text"])).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_idx = i
        if best_idx >= 0 and best_ratio >= min_ratio:
            used.add(best_idx)
            cue = vtt_cues[best_idx]
            result.append({
                **line,
                "start": cue["start"],
                "end": cue["end"],
                "source": "vtt",
                "match_ratio": round(best_ratio, 3),
            })
        else:
            result.append({**line, "start": None, "end": None, "source": "unmatched"})
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Tier 1 VTT calibration")
    parser.add_argument("--video-id", required=True)
    parser.add_argument("--lyrics", required=True, help="JSON list of lyric lines")
    parser.add_argument("--out", required=True)
    parser.add_argument("--work-dir", default="./tmp_vtt")
    args = parser.parse_args()

    work_dir = Path(args.work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    lyrics = json.loads(Path(args.lyrics).read_text(encoding="utf-8"))
    vtt_path = fetch_vtt(args.video_id, work_dir)
    if not vtt_path:
        print("No VTT found; leave all lines unmatched for Tier 2.")
        out = [{**l, "start": None, "end": None, "source": "unmatched"} for l in lyrics]
    else:
        vtt_cues = parse_vtt(vtt_path)
        out = align_lyrics_to_vtt(lyrics, vtt_cues)

    Path(args.out).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    matched = sum(1 for c in out if c.get("start") is not None)
    print(f"Matched {matched}/{len(out)} lines via VTT → {args.out}")


if __name__ == "__main__":
    main()
