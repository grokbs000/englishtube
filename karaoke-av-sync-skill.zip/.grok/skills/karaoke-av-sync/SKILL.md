---
name: karaoke-av-sync
description: Karaoke audio-video timing calibration and 60fps continuous clock engine. Use when building or fixing karaoke systems, aligning lyrics to YouTube MVs, calibrating VTT/Whisper/LRCLIB timings, compensating MV intros, or implementing smooth word-level highlight with iframe getCurrentTime jitter. Triggers include karaoke sync, lyric timing, AV alignment, 60fps clock, MV offset, Whisper word timestamps, LRCLIB, calibrate_song_timings.
---

# Karaoke AV Sync

## Overview

Specialized workflow for high-precision karaoke lyric-to-video alignment. Solves three root causes of desync (MV intro offset, mid-song early triggers, 250 ms iframe sampling jitter) via a three-tier calibration pipeline and a frontend 60 fps continuous clock with perceptual compensation.

## Core Principles

- Always prefer official VTT when available; fall back to Whisper word-level then LRCLIB.
- Treat MV visual intro length as an independent offset from studio/CD audio timing.
- Never trust raw `getCurrentTime()` for sub-250 ms decisions; always interpolate.
- Enforce monotonic increasing cue times after every alignment step.
- Measure quality by median absolute error (MAE) of word onsets against ground-truth audio.

## Three-Tier Calibration Pipeline

### Tier 1 — Official VTT Track (`calibrate_song_timings.py`)

1. Use `yt-dlp --write-subs --write-auto-subs --sub-langs en --skip-download` to fetch VTT.
2. Parse cue start/end times at millisecond precision.
3. Align bilingual lyric lines to VTT cues with `difflib.SequenceMatcher` (ratio ≥ 0.65) or token-set ratio.
4. Propagate start/end times; if a line has no match, leave it for Tier 2.
5. Output a calibrated `.lrc` or internal cue list with source = "vtt".

### Tier 2 — Whisper Word-Level Track (`batch_calibrate_whisper.py`)

When Tier 1 yields incomplete coverage or no VTT:

1. Download audio only (`yt-dlp -x --audio-format wav`).
2. Run `faster-whisper` with `model_size="base.en"`, `word_timestamps=True`, `beam_size=5`, `vad_filter=True`.
3. Obtain list of `(word, start, end)`.
4. Default alignment: Sliding-window fuzzy match each lyric line against the word stream:
   - Window size = expected syllable count ± 2.
   - Score = token-set ratio + duration similarity; accept if score > 0.42.
5. **Advanced option — DTW (Dynamic Time Warping)**:
   - Convert lyric lines and Whisper words into phoneme / character sequences.
   - Run DTW with a local distance (Levenshtein or cosine on embeddings) to find the globally optimal monotonic path.
   - Prefer DTW when fuzzy matching yields MAE > 150 ms or many unmatched lines.
   - Implementation reference: `scripts/dtw_align.py`.
6. Anchor line start to the first matched word onset; end to the last matched word offset + 0.15 s breath.
7. Apply monotonic smoothing: if `cues[i].start < cues[i-1].end`, set `cues[i].start = cues[i-1].end + 0.05`.
8. Source = "whisper" or "whisper+dtw".

### Tier 3 — LRCLIB + Smart MV Intro Compensation (`audit_and_fix_entire_catalog.py`)

For VEVO-blocked or subtitle-less videos:

1. Query LRCLIB by artist + title (or ISRC / duration fingerprint) to obtain millisecond-synced plain lyrics.
2. Compute smart offset with `compute_smart_offset(audio_path, lyric_onsets)`:
   - Extract onset envelope (librosa onset strength or simple RMS energy).
   - Cross-correlate the first 30–90 s of energy against expected first-line onsets.
   - Also try known intro heuristics (silence → first vocal energy jump).
   - Clamp candidate offsets to realistic range (−5 s … +200 s).
3. Apply the offset uniformly to all cues.
4. Cache bilingual translations (OpenCC `s2twp` for Traditional Chinese Taiwan) in memory for the session.
5. Source = "lrclib+offset".

After any tier, run a final audit:
- Check for overlapping cues, negative durations, or gaps > 30 s without instrumental markers.
- Record MAE against a held-out Whisper pass if available.

## Frontend 60 fps Continuous Clock Engine

### Exact Playback Time

```js
let baseMediaTime = 0;
let baseWallTime = 0;

function onTimeUpdate(mediaTime) {
  // Only update anchors when getCurrentTime actually changes
  if (Math.abs(mediaTime - baseMediaTime) > 0.001) {
    baseMediaTime = mediaTime;
    baseWallTime = performance.now();
  }
}

function getExactPlaybackTime() {
  const elapsed = (performance.now() - baseWallTime) / 1000;
  return baseMediaTime + elapsed + PERCEPTUAL_LEAD; // default 0.080 s
}
```

- Call `onTimeUpdate` from the YouTube IFrame API `onStateChange` / polling at 4 Hz only for anchor refresh.
- Drive all UI (word highlight, progress, countdown) from `requestAnimationFrame` using `getExactPlaybackTime()`.

### Smart Countdown UI

- If `t < cues[0].start - 0.5` → show `🎵 (前奏演奏中 · 倒數 Xs)`.
- Fade first lyric in over 0.5 s before its start.
- If gap between consecutive cues > 4.5 s → show instrumental countdown; preload next lyric 0.8 s early.
- Never flash the next line more than 0.3 s before its calibrated start.

### Zero-Allocation Word Highlight

- Pre-compute a flat array of word spans with absolute start/end.
- On each frame, binary-search the active word index.
- Apply class changes only on index transition (single classList toggle, no querySelector in hot path).

## Recommended Quality Metrics

- Word-onset MAE < 120 ms against Whisper or human annotation.
- Zero overlapping cues after smoothing.
- First-line start error < 200 ms after smart offset.
- Frontend visual lag (measured by user) < 50 ms at 60 fps.

## Common Failure Modes & Mitigations

| Failure | Cause | Mitigation |
|---------|-------|------------|
| Lyrics jump early by 30–180 s | MV intro not compensated | Always run `compute_smart_offset` when source ≠ VTT |
| Mid-song drift | Whisper beam errors on soft consonants | Raise beam_size to 5–8; post-filter by energy |
| Stuttering highlight | Polling getCurrentTime at 60 Hz | Anchor + performance.now interpolation only |
| VEVO / region block | No VTT, yt-dlp fails | Fall straight to LRCLIB + audio download from alternative mirror if needed |
| Traditional Chinese awkwardness | Generic translation | Force OpenCC `s2twp` + local glossary cache |

## File & Script Conventions

- `calibrate_song_timings.py` — Tier 1
- `batch_calibrate_whisper.py` — Tier 2
- `audit_and_fix_entire_catalog.py` — Tier 3 + catalog-wide audit
- Output format: JSON list of `{start, end, text, words: [{word, start, end}], source}`
- Keep a sidecar `.meta.json` with offset, MAE, and source for every song.

## When to Re-calibrate

- New MV upload (YouTube video ID change)
- User reports > 300 ms systematic lag
- After changing Whisper model or beam settings
- Catalog migration to a new language pack
