/**
 * Karaoke 60 fps Continuous Clock Engine
 * --------------------------------------
 * Solves YouTube IFrame API 250 ms staircase sampling jitter by anchoring
 * on real getCurrentTime() changes and interpolating with performance.now().
 *
 * Also provides smart intro/instrumental countdown and zero-allocation
 * word-level highlight via binary search.
 */

export interface WordSpan {
  word: string;
  start: number;
  end: number;
}

export interface Cue {
  start: number;
  end: number;
  text: string;
  words?: WordSpan[];
}

const PERCEPTUAL_LEAD = 0.080; // 80 ms audiovisual lead
const INTRO_COUNTDOWN_THRESHOLD = 0.5;
const INSTRUMENTAL_GAP = 4.5;
const PRELOAD_BEFORE = 0.8;

export class KaraokeClock {
  private baseMediaTime = 0;
  private baseWallTime = 0;
  private cues: Cue[] = [];
  private flatWords: WordSpan[] = [];
  private activeWordIndex = -1;
  private rafId = 0;

  /** Call whenever YouTube IFrame reports a new getCurrentTime() value. */
  onMediaTimeUpdate(mediaTime: number): void {
    if (Math.abs(mediaTime - this.baseMediaTime) > 0.001) {
      this.baseMediaTime = mediaTime;
      this.baseWallTime = performance.now();
    }
  }

  /** High-precision playback time with perceptual compensation. */
  getExactPlaybackTime(): number {
    const elapsed = (performance.now() - this.baseWallTime) / 1000;
    return this.baseMediaTime + elapsed + PERCEPTUAL_LEAD;
  }

  /** Load calibrated cues (from any of the three tiers). */
  setCues(cues: Cue[]): void {
    this.cues = cues;
    this.flatWords = [];
    for (const c of cues) {
      if (c.words?.length) {
        this.flatWords.push(...c.words);
      } else {
        // Fallback: treat whole line as one span
        this.flatWords.push({ word: c.text, start: c.start, end: c.end });
      }
    }
    this.activeWordIndex = -1;
  }

  /** Binary search for the active word at time t. */
  private findActiveWordIndex(t: number): number {
    let lo = 0;
    let hi = this.flatWords.length - 1;
    let result = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const w = this.flatWords[mid];
      if (t < w.start) {
        hi = mid - 1;
      } else if (t >= w.end) {
        lo = mid + 1;
      } else {
        return mid;
      }
    }
    // If between words, stay on previous
    if (hi >= 0 && t >= this.flatWords[hi].start) {
      result = hi;
    }
    return result;
  }

  /**
   * Call from requestAnimationFrame.
   * Returns UI state for the current frame.
   */
  tick(): {
    time: number;
    activeWordIndex: number;
    activeCueIndex: number;
    countdown: string | null;
    fadeIn: boolean;
  } {
    const t = this.getExactPlaybackTime();
    const wordIdx = this.findActiveWordIndex(t);

    // Only mutate DOM class when index actually changes
    if (wordIdx !== this.activeWordIndex) {
      this.activeWordIndex = wordIdx;
      // Consumer should apply classList changes here
    }

    // Determine active cue
    let cueIdx = -1;
    for (let i = 0; i < this.cues.length; i++) {
      if (t >= this.cues[i].start && t < this.cues[i].end) {
        cueIdx = i;
        break;
      }
    }

    // Smart countdown
    let countdown: string | null = null;
    let fadeIn = false;

    if (this.cues.length > 0) {
      const first = this.cues[0];
      if (t < first.start - INTRO_COUNTDOWN_THRESHOLD) {
        const remain = Math.ceil(first.start - t);
        countdown = `🎵 (前奏演奏中 · 倒數 ${remain}s)`;
      } else if (t < first.start) {
        fadeIn = true;
      }

      // Instrumental gaps
      for (let i = 0; i < this.cues.length - 1; i++) {
        const gap = this.cues[i + 1].start - this.cues[i].end;
        if (gap > INSTRUMENTAL_GAP) {
          if (t > this.cues[i].end && t < this.cues[i + 1].start - PRELOAD_BEFORE) {
            const remain = Math.ceil(this.cues[i + 1].start - t);
            countdown = `🎵 (間奏音樂演奏中 · 倒數 ${remain}s)`;
          }
        }
      }
    }

    return {
      time: t,
      activeWordIndex: wordIdx,
      activeCueIndex: cueIdx,
      countdown,
      fadeIn,
    };
  }

  /** Start the rAF loop. Consumer provides the render callback. */
  start(render: (state: ReturnType<KaraokeClock["tick"]>) => void): void {
    const loop = () => {
      const state = this.tick();
      render(state);
      this.rafId = requestAnimationFrame(loop);
    };
    this.rafId = requestAnimationFrame(loop);
  }

  stop(): void {
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = 0;
    }
  }
}

/* ------------------------------------------------------------------ */
/* Example integration with YouTube IFrame API                        */
/* ------------------------------------------------------------------ */

/*
import { KaraokeClock } from "./karaoke-clock";

const clock = new KaraokeClock();
clock.setCues(calibratedCues); // from Python pipeline

const player = new YT.Player("player", {
  events: {
    onReady: () => {
      // Poll at low frequency only to refresh anchors
      setInterval(() => {
        const t = player.getCurrentTime();
        clock.onMediaTimeUpdate(t);
      }, 250);
    },
  },
});

const wordEls = document.querySelectorAll(".word"); // pre-rendered spans

clock.start((state) => {
  if (state.countdown) {
    countdownEl.textContent = state.countdown;
    countdownEl.hidden = false;
  } else {
    countdownEl.hidden = true;
  }

  // Zero-allocation highlight: only touch the two elements that change
  if (state.activeWordIndex >= 0) {
    wordEls.forEach((el, i) => {
      el.classList.toggle("active", i === state.activeWordIndex);
    });
  }
});
*/
